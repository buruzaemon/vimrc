/* XPM */
/* $XConsortium: filemgr.pm /main/2 1996/07/23 12:49:01 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard */
static char *newhome48[]={
/* width height ncolors cpp [x_hot y_hot] */
"48 48 22 1 0 0",
/* colors */
"  c none m none s none",
"$ s topShadowColor     m white",
"& s background         m black",
"( s selectColor        m white",
"* s bottomShadowColor  m black",
", s white      c white     m white",
". s iconColor1 c black     m black",
"B s iconColor2 c white     m white",
"4 s iconColor3 c red       m black",
"6 s iconColor4 c green     m white",
"8 s iconColor5 c blue      m black",
"0 s iconColor6 c yellow    m black",
"2 s iconColor7 c cyan      m white",
": s iconColor8 c magenta   m white",
"< s iconGray1 c #e1e1e1e1e1e1 m white",
"> s iconGray2 c #c8c8c8c8c8c8 m white",
"@ s iconGray3 c #afafafafafaf m white",
"D s iconGray4 c #969696969696 m white",
"F s iconGray5 c #7d7d7d7d7d7d m black",
"H s iconGray6 c #646464646464 m black",
"J s iconGray7 c #4b4b4b4b4b4b m black",
"L s iconGray8 c #323232323232 m black",
/* pixels */
"                           ,,J                  ",
"                         ,,88,J                 ",
"                       ,,88888,,J               ",
"                     ,,88888,,,>>J              ",
"                    ,88888,,,>>>>J              ",
"                    ,888,,,>>>>>>>J             ",
"                    ,8,,,>>>>>>>>>J             ",
"                    ,,,>>>>>>>>>>>>J            ",
"                  ,,,>>>>>>>>>>>>>>J            ",
"   *************,,,>>>>>>>>>>>>>>>>>J           ",
"   ***********,,,>>>>>>>>>>>>>>>>>>>J           ",
"   *********,,,>>>>>>>>>>>>>>>>>>>>>>J          ",
"   ****,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,J          ",
"   *@*,4444444,:::::::,6666666,222222>J         ",
"   *@,4444444,:::::::,6666666,22222222J         ",
"   *@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<      ",
"   *@<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L      ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L      ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L      ",
"   *H<@@@@@@@@@@,,,,,,,,,,,,,,,@@@@@@@@@@L      ",
"   *H<@@@@@@@@@@,0404040404040,H@@@@@@@@@L(     ",
"   *H<@@@@@@@@@@,4040404040404,H@@@@@@@@@L((    ",
"   *@<@@@@@@@@@@,0404040404040,H@@@@@@@@@L(((   ",
"   *@<@@@@@@@@@@,LLLLLLLLLLLLL,H@@@@@@@@@L*(((  ",
"   *@<@@@@@@@@@@,LLLLLLLLLLLLL,H@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@,LHHHHHHHHHHHH,H@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@,DDDDDDDDDDDDD,H@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@,,,,,,,,,,,,,,,H@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@@HHHHHHHHHHHHHHH@@@@@@@@@L**((  ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *H<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   *@<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"   $@<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"    @<@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"     <@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"     <@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"     <@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@L**((  ",
"     <LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL**((  ",
"         (((********************************((  ",
"          (((*******************************((  ",
"           (((((((((((((((((((((((((((((((((((  ",
"            ((((((((((((((((((((((((((((((((((  ",
"                                                "
};
