/* XPM */
/* $XConsortium: exit.pm /main/2 1996/07/23 12:48:37 drk $ */
static char * Fpexit_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s bottomShadowColor	m black	c #646464646464",
"X	s iconGray1	m white	c #e1e1e1e1e1e1",
"o	s iconGray2	m white	c #c8c8c8c8c8c8",
"O	s iconGray7	m black	c #4b4b4b4b4b4b",
"+	s iconGray8	m black	c #323232323232",
/* pixels */
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"........................",
".XXXXXXXXXXXXXXXXXXXXXXX",
".XooooooooooooooooooooOX",
".Xo++++o+ooo+oOo+++++oOX",
".Xo+oooo+ooo+o+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+ooooo+++oo+ooo+oooOX",
".Xo+oooooo+ooo+ooo+oooOX",
".Xo+++oooo+ooo+ooo+oooOX",
".Xo+ooooo+++oo+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+oooo+ooo+o+ooo+oooOX",
".Xo++++o+ooo+o+ooo+oooOX",
".XooooooooooooooooooooOX",
"OXOOOOOOOOOOOOOOOOOOOOOX",
"OXXXXXXXXXXXXXXXXXXXXXXX"};
