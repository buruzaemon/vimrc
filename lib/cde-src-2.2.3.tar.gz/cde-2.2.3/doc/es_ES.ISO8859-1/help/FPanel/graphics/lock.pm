/* XPM */
/* $XConsortium: lock.pm /main/2 1996/07/23 12:52:16 drk $ */
static char * lock [] = {
/* width height ncolors cpp [x_hot y_hot] */
"40 24 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray1	m white	c #e1e1e1e1e1e1",
"X	s iconGray6	m black	c #646464646464",
"o	s iconGray4	m white	c #969696969696",
"O	s iconColor1	m black	c black",
"+	s iconGray7	m black	c #4b4b4b4b4b4b",
/* pixels */
"                                        ",
"                                        ",
"                                        ",
"                ......X                 ",
"               ..oooo..X                ",
"              ..oXOOOo.oO               ",
"              .oXO   O.oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"            ..............O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .OOOOOOOOOOOOOO             ",
"                                        ",
"                                        ",
"                                        "};
