/* XPM */
/* $XConsortium: smallprt.pm /main/2 1996/07/23 12:54:51 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconGray2	m white	c #c8c8c8c8c8c8",
"o	s bottomShadowColor	m black	c #646464646464",
"O	s topShadowColor	m white	c #c8c8c8c8c8c8",
"+	s iconGray1	m white	c #e1e1e1e1e1e1",
"@	s iconGray7	m black	c #4b4b4b4b4b4b",
"#	s iconGray5	m black	c #7d7d7d7d7d7d",
"$	s iconGray4	m white	c #969696969696",
"%	s iconGray6	m black	c #646464646464",
"&	s iconGray8	m black	c #323232323232",
"*	s iconGray3	m white	c #afafafafafaf",
"=	s selectColor	m white	c #7d7d7d7d7d7d",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"       .............            ",
"       .XXXXXXXXXX..            ",
"    ooo..X.X.XX.....oooooooO    ",
"   o.XX.XXX.XX.XXX..+XXXXXX@O   ",
"  o.X#$.............$X+XXXXX@O  ",
" o.XX%################.XXXXXX@O ",
" o.++++++++++++++++++++++++++@O ",
" o.X++++++++++++++++++%%%%%%X@O ",
" o.X++++++++++++++++++%####%X@O ",
" o.XX#################%%%%%%X@O ",
" o.XXXXXXXXXXXXXXXXXXXXXXXXXX@O ",
" o.XXXXXXXXXXXXXXXXXXXXXXXXXX@O ",
" o.XX&&&&&&&&&&&&&&&&&&XXXXXX@O ",
" o.XX&+###############&XXXXXX@O ",
" o.&&+*****************&&&&&&@O ",
"   *@$#################@@@@&OOO ",
"   *&%%%%%%%%%%%%%%%%%%&&&&&O   ",
"   OO&&&&&&&&&&&&&&&&&&o=OOO    ",
"     ooooooooooooooooooo=       ",
"      ===================       ",
"                                ",
"                                ",
"                                ",
"                                "};
