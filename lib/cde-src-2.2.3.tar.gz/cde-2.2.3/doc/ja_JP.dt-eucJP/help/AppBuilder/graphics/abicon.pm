/* XPM */
/* $XConsortium: abicon.pm /main/3 1996/12/18 01:09:01 cde-hit $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtBldr_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 15 1 0 0",
/* colors */
"     s bottomShadowColor m black c #636363636363",
".    s topShadowColor m white c #bdbdbdbdbdbd",
"X	s none	m none	c none",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray6     m black c #636363636363",
"#	s iconColor4	m white	c green",
"$    s iconGray3     m white c #adadadadadad",
"%	s iconColor2	m white	c white",
"&    s iconGray2     m white c #bdbdbdbdbdbd",
"*    s iconGray7     m black c #424242424242",
"=    s selectColor m white c #737373737373",
"-	s iconColor1	m black	c black",
";    s background    m black c #949494949494",
/* pixels */
"                                           .XXXX",
" oooooooooooooooooooooooooooooooooooooooooo.XXXX",
" oOOOOOOOOOOO+oOOOOOOOOOOOOOOOOOOOOOOOOOOOO.XXXX",
" oOoooooooooooooooooooooooooooooooooooooooo.XXXX",
" oOoOOOOOOOOO@oOOOOOOOOOOOOOOOOOOOOOOOOOOOO.XXXX",
" oOoOOOOOOOOO@oOOOOOOOOOOOOOOOOOOOOOOOOOOOO.XXXX",
" oOoOOOOOOOOO@#OO$$@OO%%%%%&&OO%%@OOOOOOOOO.XXXX",
" oOoOoooooooO@##$%%o@@%%%%oo+@O%o@OOOOOOOOO.XXXX",
" oOoOo$$$$$@O@##&%oo@@%%oooo+@@%o@OOOOOOOOO.XXXX",
" oOoOo@@@@@@O@##*oo@@@%%ooo$+@@&&@OOOOOOOOO.XXXX",
" oOoOOOOOOOOO@#%#@@@O@%$$$$$+@+&$@OOOOOOOOO.XXXX",
" oOoOOOOOOOOO@##%#%#OO@@@@@@@++@@@OOOOOOOOO.XXXX",
" o+o@@@@@@@@@@#%#%#%#@@&&+++@@@@@@@@@@@@@@@.XXXX",
" ooo&&&&&&&&&&##%#%#%#&&&OO+*OO&&&&&&&&&&&&.XXXX",
" oOo&+++++++++#%#%#%#%#&o&O+*@+++++++++++++.XXXX",
" oOo&+++++++++##%#%#%#%&oo$+*@+++++++++++++.XXXX",
" oOo&+++++++++#%#%#%#%#&o%$O*@+++++++++++++.XXXX",
" oOo&+++++++++##%#%#%#%&o%$O*@+++++++++++++.XXXX",
" oOo&+++++++++#%#%###%#&o%$O@@+++++++++++++.XXXX",
" oOo&+++++++++##%#%#+#%&o%$O@@+++++++++++++.XXXX",
" oOo&+++++++++#%#%##+O#&o%$O@@+++++++++++++.XXXX",
" oOo&+++++++++##%#%#+OO&o%$O#@+++++++++++++.XXXX",
" oOo&+++++++++#%#%##+OO&o%$OO#@++++++++++++.XXXX",
" oOo&+++++++++##%#%#+OO@@@**#O#@+++++++++++.XXXX",
" oOo&@@@@@@@@@#%#%##@@@@@@***#%#@@@@@@@@@@@.XXXX",
" oOo@@@@@@@@@@##%#%#@@@O++***O#%#@@@@@@@@@@.XXXX",
" oOo&&&&&&&&&&#%#%##&&@++****#%#%#@&&&&&&&&.XXXX",
" oOo$$$$$$$$$$##%#%#O$@O++*+*##%#%#@$$$$$$$.XXXX",
" oOo$$$$$$$$$$#%#%##O$@++****+##%#%#@$$$$$$.XXXX",
" oOo$$$$$$$$$$##%#%#O$@O++*+*++##%#%#@$$$$$.XXXX",
" oOo$$$$$$$$$$#%#%##O$@++****++$##%#%#@$$$$.XXXX",
" oOo$$++++++++##%#%#++@O++*+***++##%#%#@+++.XXXX",
" oOo$$+$O$O$O$#%#%##$O@++****+O$O$##%#%#@O$.XXXX",
" oOo$$+O$O$O$O##%#%#O$@O++*+*O+O$OO##%#%#@O.XXXX",
" oOo$$+$O$O$O$#%#%###o@++****o#o#oo###%#%#@.XXXX",
" oOo$$+O$O$O$O##%#%#%#@O++*+*#$#%##%#%#%#%#.XXXX",
" oOo$$+$O$O$O$#%#%#%#%@++****$#%#%%#%#%#%#%#XXXX",
" oOo$$+O$O$O$O##%#%#%#@O++*+*#$#%##%#%#%#%#%#XXX",
" oOo$$+$O$O$O$########@++****#################XX",
" oOo$$+O$O$O$O$O$O$O$+@O++*+*++++++++++++++.=XXX",
"-oOo$$+$O$O$O$O$O$O$O$@++****+O$O$$O$O$O$O$.==XX",
"-oOo$$+O$O$O$O$O$O$O$O@O++*+*O+O$OO$O$O$O$O.XXXX",
" .....................@++****...............XXXX",
"XXXXXXXXXXXXXXXXXXXXXX@O++*+*==XXXXXXXXXXXXXXXXX",
"XXXXXXXXXXXXXXXXXXXXXX@++****=XXXXXXXXXXXXXXXXXX",
"XXXXXXXXXXXXXXXXXXXXXX@******==XXXXXXXXXXXXXXXXX",
"XXXXXXXXXXXXXXXXXXXXXXX=======XXXXXXXXXXXXXXXXXX",
"XXXXXXXXXXXXXXXXXXXXXXXX=X=X=;=XXXXXXXXXXXXXXXXX"};
