/* XPM */
/* $XConsortium: persapps.pm /main/2 1996/07/23 12:31:48 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fpenpad [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 16 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray6     m black c #636363636363",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray7     m black c #424242424242",
"&	s iconColor1	m black	c black",
"*	s iconColor6	m white	c yellow",
"=    s iconGray2     m white c #bdbdbdbdbdbd",
"-    s iconGray4     m white c #949494949494",
";	s iconColor8	m black	c magenta",
":    s selectColor m white c #737373737373",
/* pixels */
"                                                ",
"                                                ",
"    ................................            ",
"    .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOO@O@O#OOOO@OOO#@OOOOOOOO+o            ",
"    .XOOOO+#O+##O++O#@+##@#OOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOO@OO@OO@OOOOO@@OOOOOOOOOO+o            ",
"    .XOOOO#+++OO#OO+OO+@#+OO#++OOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o            ",
"    .XOOOO#@#@OOOO+O+O$OOOOOOOOOOO+o            ",
"    .XOOOO+@@#@+O+@$@+$OOOOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOO%+$$@OOOOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOO%&&&@@OOOOOOO+o            ",
"    .XOOOOOOOOOOOOOOO%&&&@@@OOOOOO+o            ",
"    .XOOOOOOOOOOOOOOO%@&O**=@OOOOO+o            ",
"    .XOOOOOOOOOOOOOOO%#@@O**=@OOOO+o            ",
"    .XOOOOOOOOOOOOOOOO##@OO**=@OOO+o            ",
"    .XOOOOOOOOOOOOOOOO%%#@OO**=@OO+o            ",
"    .XOOOOOOOOOOOOOOOO@%%#@OO**=@O+o            ",
"    .XOOOOOOOOOOOOOOOO@@%##@OO**=@+o            ",
"    .XOOOOOOOOOOOOOOOO=@@%%#@OO**=@o            ",
"    .XOOOOOOOOOOOOOOOOO=@@%%#@OO**=@            ",
"    .XOOOOOOOOOOOOOOOOOO=@@%##@OO**=@           ",
"    .XOOOOOOOOOOOOOOOOOOO=@@%%#@OO**=@          ",
"    .XOOOOOOOOOOOOOOOOOOOO=@@%%#@OO**=@         ",
"    .XOOOOOOOOOOOOOOOOOOOOO=@@%%#@OO**=@        ",
"    .XOOOOOOOOOOOOOOOOOOOOOO=@@%##@OO**=@       ",
"    .XOOOOOOOOOOOOOOOOOOOOOOO=@@%%#@OO**=@      ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOO=@@%%#@OO--@=     ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOO=@@%##@-OO%%-    ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOO=@+%##@O%O%%=   ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOO=+ %%%##%OO;%  ",
"    .XOOOOOOOOOOOOOOOOOOOOOOOOOOOO+ ::%%#-O;-%  ",
"    .X+++++++++++++++++++++++++++++ ::%%%-;-;%  ",
"    .ooooooooooooooooooooooooooooooo:::%%#-;%%% ",
"                                     :::.%%%%.::",
"                                      :::%%%%:::",
"                                       :::::::::",
"                                        ::::::: ",
"                                          : :   ",
"                                                "};
