/* XPM */
/* $XConsortium: fplight.pm /main/3 1995/07/18 17:34:00 drk $ */
static char * fplight [] = {
/* width height ncolors cpp [x_hot y_hot] */
"36 22 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor1	m black	c black",
"X	s iconColor6	m white	c yellow",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O	s iconColor4	m white	c green",
"+    s iconGray7     m black c #424242424242",
/* pixels */
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"      ..................            ",
"      .XXXXXXXXXXXXXXXXo            ",
"      .XOXOXOXOXOXOXOX+o            ",
"      .XOXOXOXOXOXOXOX+o            ",
"      .XOXOXOXOXOXOXOX+o            ",
"      .XOXOXOXOXOXOXOX+o            ",
"      .X+++++++++++++++o            ",
"      .ooooooooooooooooo            ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    ",
"                                    "};
