/* XPM */
/* $XConsortium: fplock.pm /main/3 1995/07/18 17:34:10 drk $ */
static char * lock [] = {
/* width height ncolors cpp [x_hot y_hot] */
"40 24 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray4     m white c #949494949494",
"O	s iconColor1	m black	c black",
"+    s iconGray7     m black c #424242424242",
/* pixels */
"                                        ",
"                                        ",
"                                        ",
"                ......X                 ",
"               ..oooo..X                ",
"              ..oXOOOo.oO               ",
"              .oXO   O.oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"              .oO     .oO               ",
"            ..............O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .oXXXXXXXXXXX+O             ",
"            .oooooooooooo+O             ",
"            .OOOOOOOOOOOOOO             ",
"                                        ",
"                                        ",
"                                        "};
