/* XPM */
/* $XConsortium: cauticon.pm /main/4 1996/06/19 16:19:29 drk $ */
static char * cauticon [] = {
/* width height ncolors cpp [x_hot y_hot] */
"31 28 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor1	m black	c black",
"X	s iconColor5	m black	c blue",
"o	s iconColor6	m white	c yellow",
/* pixels */
"             .....             ",
"            .XXXXX.            ",
"           .XXoooXX.           ",
"          .XXoooooXX.          ",
"          .XoooooooX.          ",
"         .XXoooooooXX.         ",
"        .XXoooXXXoooXX.        ",
"        .XoooXXXXXoooX.        ",
"       .XXoooXXXXXoooXX.       ",
"      .XXooooXXXXXooooXX.      ",
"      .XoooooXXXXXoooooX.      ",
"     .XXoooooXXXXXoooooXX.     ",
"    .XXooooooXXXXXooooooXX.    ",
"    .XooooooooXXXooooooooX.    ",
"   .XXooooooooXXXooooooooXX.   ",
"  .XXoooooooooXXXoooooooooXX.  ",
"  .XooooooooooXXXooooooooooX.  ",
" .XXooooooooooXXXooooooooooXX. ",
".XXoooooooooooooooooooooooooX. ",
".XXoooooooooooooooooooooooooXX.",
".XooooooooooooXXXooooooooooooX.",
".XoooooooooooXXXXXoooooooooooX.",
".XoooooooooooXXXXXoooooooooooX.",
".XXoooooooooooXXXoooooooooooXX.",
" .XoooooooooooooooooooooooooX. ",
" .XXXoooooooooooooooooooooXXX. ",
"  ..XXXXXXXXXXXXXXXXXXXXXXX..  ",
"    .......................    "};
