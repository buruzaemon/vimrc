/* XPM */
/*
 * @DEC_COPYRIGHT@
 */
/*
 * HISTORY
 * $Log$
 * Revision 2.1  1994/12/31  00:15:51  devrcs
 * Initial load of project in OSF/1 pool
 *
 * Revision 1.1  1994/12/30  22:15:37  devrcs
 * Initial load of original source
 *
 * Revision 1.2.2.2  1994/11/07  04:13:54  Alaa_Zeineldine
 * 	Fixing XPM Header
 * 	[1994/10/31  23:59:40  Alaa_Zeineldine]
 *
 * Revision 1.2  1994/09/05  18:12:28  devrcs
 * 	Initial load of project
 * 
 * $EndLog$
 */
/*
 * @(#)$XConsortium: drawarea.pm /main/2 1996/07/18 15:32:32 drk $
 */
/* XPM */
static char * drawarea_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 32 19 1 0 0",
/* colors */
" 	s iconColor1	m black	c black",
".	s iconGray4	m white	c #969696969696",
"X	s iconGray2	m white	c #c8c8c8c8c8c8",
"o	s iconGray1	m white	c #e1e1e1e1e1e1",
"O	s iconGray6	m black	c #646464646464",
"+	s iconColor6	m white	c yellow",
"@	c #D9D9D9D9D9D9",
"#	c #B7B7B7B7B7B7",
"$	s iconGray3	m white	c #afafafafafaf",
"%	s iconGray8	m black	c #323232323232",
"&	s iconColor2	m white	c white",
"*	c #BFBF26262626",
"=	s iconGray5	m black	c #7d7d7d7d7d7d",
"-	s iconColor3	m black	c red",
";	c #E5E5B1B12D2D",
":	c #3E3E57578C8C",
"?	c #61618787D9D9",
">	c #C4C4D7D7FFFF",
",	c #8C8C8C8C8C8C",
/* pixels */
"                                          .     ",
" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXXXXX+@+@+@+@+XXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXXXX+@+@+@+@+#XXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXXX+@+@+@+@+#+XXXXXXXXXXXXXXXXXXo. $#%X",
" XXXXXXXXXX+++++++&+#+#XX#*XXXXXXXXXXXXXXo. $=%X",
" XXXXXXXXXX+++++++&#+#+XX-*XXXXXXXXXXXXXXo. $=%X",
" XXXXXXXXXX+++++++&+#+#X;#-*XXXXXXXXXXXXXo. $=%X",
" XXXXXXX:::::+++++&#+#+X;-#**XXXXXXXXXXXXo. $=%X",
" XXXXXX:::::::++++&+#+#;-#-#*XXXXXXXXXXXXo. $=%X",
" XXXXX::???::::+++&#+#+;#-#-**XXXXXXXXXXXo. $=%X",
" XXXX::>>>??::::++&+#+;#-#-#-**XXXXXXXXXXo. $=%X",
" XXX::?>>>???::::+&#+#;-#-#-#***XXXXXXXXXo. $=%X",
" XXX::?>>>???::::,&+#;-#-#-#-#**XXXXXXXXXo. $=%X",
" XXX::???????::::,&#+;#-#-#-#-#**XXXXXXXXo.    X",
" XXX:::?????:::::,&+;#-#-#-#-#-***XXXXXXXo. OOOX",
" XXX::::???::::::,&#;-#-#-#-#-#-***XXXXXXo. OOOX",
" XXXX:::::::::::,,&;-#-#-#-#-#-#***XXXXXXo. OOOX",
" XXXXX:::::::::,,+&;#-#-#-#-#-#-#*XXXXXXXo. OOOX",
" XXXXXX:::::::,,++&,,,,XXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXX:::::,,+++&+#+#XXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXX,,,++++&#+#+XXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXX+++++++&+#+XXXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXX++++++++#+XXXXXXXXXXXXXXXXXXXXo. OOOX",
" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo. OOOX",
" ooooooooooooooooooooooooooooooooooooooooo, OOOX",
".........................................,..XXXX",
"                                          ......",
" OOOOOOOOOOXXXXXXXXXXXXXXXXXXXX%OOOOOOOOOOX.....",
" OOOOOOOOOOX...................%OOOOOOOOOOX.....",
" OOOOOOOOOO%%%%%%%%%%%%%%%%%%%%%OOOOOOOOOOX.....",
" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX....."};
