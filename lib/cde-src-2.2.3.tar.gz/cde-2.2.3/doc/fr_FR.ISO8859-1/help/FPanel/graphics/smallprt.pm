/* XPM */
/* $XConsortium: smallprt.pm /main/2 1996/07/23 13:24:45 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s bottomShadowColor m black c #636363636363",
"O    s topShadowColor m white c #bdbdbdbdbdbd",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray4     m white c #949494949494",
"%    s iconGray6     m black c #636363636363",
"&    s iconGray8     m black c #212121212121",
"*    s iconGray3     m white c #adadadadadad",
"=    s selectColor m white c #737373737373",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"       .............            ",
"       .XXXXXXXXXX..            ",
"    ooo..X.X.XX.....oooooooO    ",
"   o.XX.XXX.XX.XXX..+XXXXXX@O   ",
"  o.X#$.............$X+XXXXX@O  ",
" o.XX%################.XXXXXX@O ",
" o.++++++++++++++++++++++++++@O ",
" o.X++++++++++++++++++%%%%%%X@O ",
" o.X++++++++++++++++++%####%X@O ",
" o.XX#################%%%%%%X@O ",
" o.XXXXXXXXXXXXXXXXXXXXXXXXXX@O ",
" o.XXXXXXXXXXXXXXXXXXXXXXXXXX@O ",
" o.XX&&&&&&&&&&&&&&&&&&XXXXXX@O ",
" o.XX&+###############&XXXXXX@O ",
" o.&&+*****************&&&&&&@O ",
"   *@$#################@@@@&OOO ",
"   *&%%%%%%%%%%%%%%%%%%&&&&&O   ",
"   OO&&&&&&&&&&&&&&&&&&o=OOO    ",
"     ooooooooooooooooooo=       ",
"      ===================       ",
"                                ",
"                                ",
"                                ",
"                                "};
