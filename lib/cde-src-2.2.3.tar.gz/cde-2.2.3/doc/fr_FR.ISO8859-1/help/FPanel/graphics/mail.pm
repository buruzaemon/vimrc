/* XPM */
/* $XConsortium: mail.pm /main/2 1996/07/23 13:22:37 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fmail_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s topShadowColor m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray5     m black c #737373737373",
"$	s iconColor2	m white	c white",
"%	s iconColor3	m black	c red",
"&	s iconColor5	m black	c blue",
"*    s iconGray6     m black c #636363636363",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"      ...................................X      ",
"      .oooooooooooooOoOoOoOoOoOOOOOOOOOO+XX     ",
"     ..O@@@+@+@+@+@+@+@+@+#+#+#+##########X     ",
"    ..oooooooooooOoOoOoOoOoOOOOOOOOOOOOOO#XX    ",
"    .@@@@+@+@+@+@+@#+#+#+#+#+#+############X    ",
"    .$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#X    ",
"    .$o$o$o$o$o$o$o$o$o$o$o$o$o%%$%%o$OOO$#X    ",
"    .$##$###$#$o$o$o$o$o$o$o$%%o$%$o%oO&Oo#X    ",
"    .$o$o$o$o$o$o$o$o$o$o$o$o$o%%%o$%$O&O$#X    ",
"    .$####$###$o$o$o$o$o$o$o$%%o$o%%$oOOOO#X    ",
"    .$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$O$O$Oo#X    ",
"    .$$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$OoO#X    ",
"    .$o$o$o$o$o$o$o$o$o$o$o$o$o$o$O$O$OoOo#X    ",
"    .$$o$o$o$o$o$o$o$o$o$o$o$o$o$o$o$OoOoO#X    ",
"   .O$o$o$o$o$o$o$o$o$o$o$o$o$o$O$O$OoOoO@#@.   ",
"  .oO$$o$o$o$o$o$o$o$o$o$o$o$o$o$o$OoOoO@O#o@.  ",
" .o$+$ooooooooo$o$o$o$o$o$o$o$O$O$OoOoO@O@#@o@. ",
".o$@@@@@@@@@OoO#####$###$#####$###ooOOOOOOOOOo*X",
".+oooooooooo+@+OO$o$o$o$o$o$o$O$OooOooooooooo#*X",
".+@Oo$OoooOoo#@####o######$####O##OoooOo@@@+@#*X",
".+@o$$$OoOoOo#+@O$o$o$o$o$O$O$OoOoOooOoOO@++##*X",
".+@Oo$OoOoOoo#@+@O$o$o$o$o$o$OoOoOOoOoOo@@@+@#*X",
".+@o$$$OoOoOo#+@@Oo$o$o$O$O$OoOoOoOooOoOO@++##*X",
".+@Oo$OoOoOooo#+@OOOOOOOOOO@O@O@OOooOoOo@@@+@#*X",
".+@o$$$OoOoOooo#####+++++++@@OOOOooOoOoOO@++##*X",
".+@Oo$OoOoOoOoOoooooooooooooooooooOoOoOo@@@+@#*X",
".+@o$$$OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOO@++##*X",
".+@Oo$OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOo@@@+@#*X",
".+@o$$$OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOO@++##*X",
".++#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+##**X",
" X********************************************X ",
"  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
