/* XPM */
/* $XConsortium: template.t.pm /main/3 1995/07/18 16:06:44 drk $ */
static char * template_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray6     m black c #636363636363",
/* pixels */
"                ",
" ......         ",
" .XXXXo         ",
" .XXXXo    .    ",
" .XXXXo   .Xo   ",
" .XXXXo   .Xo   ",
" .ooooo  .XXXo  ",
"         .XXXXo ",
"        .XXXXXo ",
"        .oooooo ",
"      ...       ",
"     .XXXo      ",
"    .XXXXXo     ",
"    .XXXXXo     ",
"     .XXXo      ",
"      ooo       "};
