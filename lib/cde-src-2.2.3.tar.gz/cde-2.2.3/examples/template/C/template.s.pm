/* XPM */
/* $XConsortium: template.s.pm /main/3 1995/07/18 16:06:36 drk $ */
static char * template_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray6     m black c #636363636363",
/* pixels */
"                        ",
"  .........             ",
"  .XXXXXXXo             ",
"  .XXXXXXXo             ",
"  .XXXXXXXo             ",
"  .XXXXXXXo     ..      ",
"  .XXXXXXXo    .XXo     ",
"  .XXXXXXXo    .XXo     ",
"  .XXXXXXXo   .XXXXo    ",
"  .oooooooo   .XXXXXo   ",
"              .XXXXXo   ",
"             .XXXXXXo   ",
"            .XXXXXXXXo  ",
"            .ooooooooo  ",
"        ....            ",
"       .XXXXo           ",
"      .XXXXXXo          ",
"     .XXXXXXXXo         ",
"     .XXXXXXXXo         ",
"     .XXXXXXXXo         ",
"     .XXXXXXXXo         ",
"      .XXXXXXo          ",
"       .XXXXo           ",
"        oooo            "};
