:::::::::::::::::::::::::::::: Vivacious Colors Icon Theme :::::::::::::::::::::::::::::::::::



:::::::::::::::::::::::: The Official Manual And Release Notes :::::::::::::::::::::::::::::::

::::::::::::::::::::::::::::: Version 1.3 (September 2015+) :::::::::::::::::::::::::::::


Like this theme?

Please Support All These Great Open Source Icon Themes/Projects 
who make up this theme and make it possible:

http://nitrux.in/
https://github.com/NitruxSA/plasma-next-icons
http://vinceliuice.deviantart.com/art/Emerald-icons-theme-490755152
http://mokaproject.com/about/
http://tiheum.deviantart.com/
https://numixproject.org/
http://elementaryos.org/ 

Then Come Visit US At: http://www.ravefinity.com/ 
for this theme and more themes like it.


:::::::::::::::::::::About This Theme:::::::::::::::::::::

Vivacious Colors is a NEW modern, clean and bold GTK icon theme. Featuring an "vivid" and completely NEW set of application icons. And amazing folders and indicators. All icons in vivacious are flat and modern but use gradients and shading for more detail and sophistication. Vivacious uses a fusion of components from many great open source icon projects. But we add to and develop many new aspects of our own on top of this Including taking on new App icon development & re-design and other aspects as needed. Vivacious features 4 refined folder colors by default. and 10 more installable via the folder-colors package.

Vivacious Colors is based on our tried and true Vibrancy Colors icon theme framework (Folders, Indicators, Actions etc). However we have completely replaced the rounded App icons with a newly re-designed (With some parts built from scratch) Set of vivid and beautiful application icons that come in multiple shapes and are fully SVG.

Vivacious uses Plasma Next icons as a base for our app icons. However we have overhauled the look of nearly everything (to match our design vision) We have also created lots of new icons and redesigned many aspects. The theme has also been built out so nearly all common apps and even uncommon ones "theme" with our theme! A huge thanks to the Emerald Icon theme and Vince Luice for his hard work making Plasma Next Icons more GTK friendly. Vivacious is based on Emerald and Plasma but we look different as we have gone in a different direction.
  
Vivacious Colors is a GTK Icon theme by RAVEfinity.

4 Folder colors come bundled by default! Stock Manila Folders, Blue, Purple, And Mint Teal.

(!) More Colors of Folders are available by installing the "vivacious-folder-colors" package or downloading the tar:
See ravefinity.com for this, And click on Vivacious Colors.

That package features 10 more colors of folders:
Aqua , Graphite , Blue Vivid (Dark), Brown, Green, Purple Vivid (Dark), Red , Pink, Orange, Yellow.

Folder color extension is fully supported for all the colors out of the box. 

5 Versions are Selectable:
Just play with it if you don't understand what this means, be sure to open gedit or something with a toolbar so you know what is what.

Vivacious Light - Dark Monochrome Panel Icons For Light Panels. And Dark Monochrome Icons For Toolbar Icons
Vivacious Dark - Light Monochrome Panel Icons for Dark Panels. And Dark Monochrome Icons For Toolbars Icons.
Vivacious Full Dark - Light Monochrome Panel Icons for Dark Panels. And Light Monochrome Icons For Toolbars Icons.

Vivacious-NonMono-Dark- Keeps the Light Monochrome panel icons for a Dark panel theme. but then provides traditional toolbar icons (Color based)
Vivacious-NonMono-Light- Keeps the Dark Monochrome panel icons for a Light panel theme. but then provides traditional toolbar icons (Color based)

Vivacious Colors should work on any GTK Desktop On Any distro. but it has not been tested on ones released before then 2014. We did some complex linking and inheriting to make the theme slim and as few files as possible (We got it down from 121,000 files to about 43,000) this may cause issues on some older desktops but most likely not.


-Changelog-

1.3 - More enhanced and beautified icons, New Printer, Blender, Karbon, New Kodi Icon and alot more!

1.2 - New Icons, Redone Icons, Fixes, Spotify Icon fixed, Battery on Cinnamon/GnomeShell uses proper mono icon.

1.1 - First Release, Based on Vibrancy Colors 2.2.1 Framework. New App Icons, refined folder colors, a new theme!.

PLEASE SUPPORT THE ORIGINAL AUTHORS:
THIS THEME IS MADE UP OF OTHERS AMAZING OPEN SOURCE HARD WORK:

Do Not credit us for everything, This theme is made up of others beautiful hard work, please support the authors. 
We do not want to hurt anyones endeavors or the community.


Application Icons, Majority Of Icons used in Theme are based on:
Plasma-Next Icons & Flattr Icons
(C)2014-2015 Uri Herrera (Plasma & KDE Visual)
Main Design by: Uri Herrera. (http://nitrux.in/)
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/ )
URL: https://github.com/NitruxSA/plasma-next-icons


More App Icons, And a built out base with more apps:

Emerald Icons
(C)2014-2015 Vince Liuice
http://vinceliuice.deviantart.com/art/Emerald-icons-theme-490755152
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/4.0/us/ )
URL: https://github.com/NitruxSA/plasma-next-icons


Device Icons
Faba & Moka Icon Theme 
That is designed and developed by 

(C) 2014 Sam Hewitt 

Please support Sam here Buy Him a Coffee or Donate...
http://mokaproject.com/about/


System Panel Indicators (Monochromes), App Toolbar Icons, Few Others 

Are The Faenza Icons designed and developed by:
(C) 2012-2014 Matthieu James

Please Support Tiheum here:
http://tiheum.deviantart.com/


Mime type Icons 

Are The Numix Square Icon Theme
(C) 2013-2014 Numix Project

Please support the Numix folks here donate or buy something fancy :) :
https://numixproject.org/

Folder Icons.

Are The KDE Breeze Folder Icons.

(C)2014 KDE Visual Group (KDE Open Source Project)
Main Design by: Uri Herrera. (Please Visit: http://nitrux.in/)


Symbols Used On Folders

Are From the elementary icon theme.

elementary Icons & Theme.
(C) 2011-2014 Daniel Foré.

Please support elemntary at:
http://elementaryos.org/ 

Overall Design for this icon theme Vivacious Flat 
Merged together, tweaked and compiled & some design by the RAVEfinity Project, 

You can visit us At: http://www.ravefinity.com/

(C) 2014 , Jared Sot.


:::::::::::::::::::::Features:::::::::::::::::::::

Vivacious Colors is a beautiful flat and "vibrant" icon theme. Vivacious is a mixture of many of the top open source icon themes into a new beautiful theme.
Vivacious Flat features Vivid and beautiful application icons (A slightly tweaked version of the Moka Icon Theme) 13 Different Folder Colors Selectable Based on KDE 5's Breeze Folders. Along with support for 3 types of monochorme panels & Tool-bar configurations Based on Faenza.

Vivacious Colors is a fusion (Mix) of many beautiful Open source icons themes into a "Newish" beautiful awesome flat icon theme.

Vivacious Colors is a mixture of:

Moka Icons (For Application icons & majority of icons, We Slightly Modified a few app icons) 

Numix Square Icon Theme (Mime type Icons)

Faenza Icons (System Panel Indicators (Monochromes), App Toolbar Icons, Few Others )

KDE 5 Breeze Icons (Folder Icons (Modified Color And Symbols , Ported to GTK by RAVEfinity)
 
elementary folder Symbols (Symbols used on folders eg music downloads etc.) 

RAVEfinity Design (Icons Mixed together,crafted,tested and tweaked by RAVEfinity)


:::::::::::::::::::::SPACE REQUIREMENTS:::::::::::::::::::::


85 MB For Entire Install (Uncompressed)


:::::::::::::::::::::Copyrights & Credits:::::::::::::::::::::


This work is based on and Licensed under 2 open source licenses.

License 1, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/
License 2, GPL v2 & v3 , http://www.gnu.org/copyleft/gpl.html


Brought to you by(& Based on):


Application Icons, Category Icons (Majority of artwork):

Are The Faba & Moka Icon Theme that is designed and developed by 

(C) 2014 Sam Hewitt <hewittsamuel@gmail.com>

Please support Sam here...
http://mokaproject.com/about/
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/ )


System Panel Indicators (Monochromes), App Toolbar Icons, Few Others 

Are The Faenza Icons designed and developed by:
(C) 2012-2014 Matthieu James <matthieu.james@gmail.com>

Please Support Tiheum here:
http://tiheum.deviantart.com/
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/ )


Mime type Icons 

Are The Numix Square Icon Theme
(C) 2013-2014 Numix Project

Please support the Numix folks here:
https://numixproject.org/
(License, GPL , http://www.gnu.org/copyleft/gpl.html)


Folder Icons.

Are The KDE Breeze Folder Icons.

(C)2014 KDE Visual Group (KDE Open Source Project)
Main Design by: Uri Herrera. (No Email or URL Provided in copyright & about file, We will add if found.)
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/ )
Please support kde at kde.org

Symbols Used On Folders

Are From the elementary icon theme.

elementary Icons & Theme.
Daniel Foré <Daniel.p.Fore@gmail.com>

Please support elemntary at:
http://elementaryos.org/ 

Overall Design for this icon theme Vivacious Flat 
Merged together, tweaked and compiled by the RAVEfinity Project, 

You can visit us At: http://www.ravefinity.com/

(C) 2014 , Jared Sot. <ravefinity@gmail.com>
(License, Creative Commons SA, https://creativecommons.org/licenses/by-sa/3.0/us/)


:::::::::::::::::::::ABOUT THEMES :::::::::::::::::::::


Most GTK 2 & 3 themes  or Icon Themes for Linux (BSD etc) are distributed in a tar.gz or zip format. by default. (Or more specifically  Source)

Some themes are available in .deb packages or rpm etc.. See our website to download them! If you get one in those formats you can safely install it (By double clicking on it) avoiding the need for manual installation discussed here.

This guide covers manually installing themes from SOURCE or tar.gz files! despite the "Scary name" there is no compiling or difficult things needed to a install a theme this way. Believe it or not the only thing you have to do is copy the theme files into the proper folder and your desktop should automatically recognize them!

Heres how we do that...
Thats being said just install and activate it on your desktop as shown bellow...

(!) Always back up your data and use these instructions at own risk! its not ours nor our contributors fault if anything goes wrong.
We have taken great strides to provide clear concise and safe instructions! But as always Do This at your own risk ! No Warranty!


:::::::::::::::::::::How to Install:::::::::::::::::::::


(!) THIS IS FOR MANUALLY INSTALLING THE THEME IF YOU OBTAINED IT IN A TAR.GZ FILE.
IF YOU INSTALLED IT FROM OUR PPA .DEB, RPM ECT YOU CAN SAFELY SKIP TO THE NEXT SECTION "ACTIVATING THE THE THEME" (IT'S ALREADY INSTALLED)

IF YOU'D LIKE TO GET IT OR INSTALL IT THAT WAY 
SIMPLY VISIT: http://www.ravefinity.com/

:::: Install The Icon Theme. *System Wide* Recommended ::::

(Note: this Method requires Root or SUDO privileges)

YOU DO NOT NEED TO INSTALL THIS WAY IF YOU USE OUR OFFICAL PPA OR UBUNTU,MINT OR DEBIAN .DEB PACKAGES, SIMPLEY CLICK DOWNLOAD CLICK , AND CLICK INSTALL!

Overview of what we need to do:To Intsall any Icon theme You Simply Extract the complete package you just downloaded the "ThemeName.tar.gz" (Folders and all)
to the themes folder for your entire system..."/usr/share/Icons/"

(Open A Terminal by Pressing Ctrl+Alt+T or by browsing for it on your menu)

1.) Open a terminal and type: sudo file-roller (Then type your password when asked)
-Fedora/Redhat Users Without sudo, type: "su -c file-roller" (Then type the root password)

4.) Now You will see the File Roller Archiver application...

Click "File -> Open" Then Browse for the package you just downloaded: "IconThemeName.tar.gz". Then click open.

5.) Once You've opened the "IconThemeName.tar.gz" file,

Select "Extract". Then Browse to the fallowing folder:"/usr/share/Icons/" Then click ok!

6.)The  Theme Should now be installed! Now all you must do is select the Theme VIA your desktops theme manager! (See other help section on how to do this)

Please Note: If this themes comes with a GTK theme please install that separately.

Manually Install The Icon Theme.  *For Your User Account Only* (Meathod 2)

NOTE: This is NOT how you install GTK Themes see that dedicated section on that.


:::: Install The Theme for *your user account only* ::::

YOU DO NOT NEED TO INSTALL THIS WAY IF YOU USE OUR OFFICAL PPA OR UBUNTU,MINT OR DEBIAN .DEB PACKAGES, SIMPLEY CLICK DOWNLOAD CLICK , AND CLICK INSTALL!

1.) Click to Open Up the package file you just downloaded... "IconThemeName.tar.gz"

2.) Once Open, Click the "Extract" Button... Then Browse to: /Home/YourUserName/.Icons

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory.

3.) Extract the complete package "IconThemeName.tar.gz" file (Folders and all)
to the ".Icons" folder in your home directory.

4.) Select it VIA your Theme Manager! Please See Bellow...

(!) This will install the theme for the current user only , Evey user will have to do this on there own!, Thats why we recommend the system wide method (Above) 


:::::::::::::::::::::Using Your New Theme:::::::::::::::::::::


Once a theme is installed (See Previous Section on how to do so)
All you must do is activate it or tell your desktop to use it instead of the default or current theme.

Start using your new icon theme as fallows...


::::The On Cinnamon desktop::::

1.) Locate and start the "System Settings" It's A Grey Gear Icon. 

Menu -> The Gears Icon On The Side. Under Firefox and The Package Manager.

2.) Click On The Themes Icon

3.) Click On The Other Settings Tab.

4.) Select Desired Version Of Icons From Icons Drop Down Box.

5.) Have Fun!

::::On Gnome 3 desktops::::


1.) Locate and start the "unity-tweak-tool" (Sometimes labeled "Advanced Settings") in your menu. (Install it if needed)

Or if you don't have that use

1 alt.) Locate and start the "Gnome Tweak Tool" (Sometimes labeled "Advanced Settings") in your menu. (Install it if needed)

How-to Install this tool:

Ubuntu,Debian & Mint
Install via searching for "unity-tweak-tool" in the Software Center or Synaptic Package manger or simply type: sudo apt-get install gnome-tweak-tool ,in a terminal or Run Command

Or if you don't have that

Install via searching for "unity-tweak-tool" in the Software Center or Synaptic Package manger or simply type: sudo apt-get install gnome-tweak-tool ,in a terminal or Run Command


Fedora and Redhat
Install via searching for "gnome-tweak-tool" in Add/Remove Software or type: yum install gnome-tweak-tool ,in a terminal or Run Command

Start using theme via "Unity Tweak Tool"

(In Unity:)
Get to your menu of applications by Clicking the Ubuntu Logo or pressing the "Super Key" eg. The Windows(TM) Logo Key

Now simply navigate to the "settings" or "system tools" application category in your menu, or type "Unity Tweak" in the unity search box and launch the application.

3.) Once the "Unity Tweak Tool" application is open...
Select the "Icons" option from the grid.

4.) Now select your desired version of RAVE-X from the list boxes.
.. Your Done!


(Alternate method) Start using theme via "Gnome Tweak Tool" (Sometimes labeled "Advanced Settings")

(In Unity:)
Get to your menu of applications by Clicking the Ubuntu Logo or pressing the "Super Key" eg. The Windows(TM) Logo Key

(In Gnome 3:)
Get to your menu by clicking activities then clicking "applications" or pressing the "Super Key" eg. The Windows(TM) Logo Key.

Now simply navigate to the "settings" or "system tools" application category in your menu, or type "Gnome Tweak Tool" in the search box and launch the application.

3.) Once the "Gnome Tweak Tool" application is open...
Select the "Icons" option from the list of options on the left.

4.) Now select your desired version of Vivacious Flat from the Icons Tab
Click apply.. Your Done!

(!) Now You may need to login and log back out for the theme to display correctly or take effect. (Thats How GTK 3 and Gnome 3 work for now)


:::::::::::::::::::::On Gnome 2/MATE:::::::::::::::::::::


Simply select your desired theme, GTK2 Theme , and Window Border on your Desktops Theme Manager:

-On Gnome2, Mate and Unity Desktops (11.04 Only) Do this-

1.) Right Click on the desktop

2.) Select Change Background

3.) Click on the "Themes tab"

4.) Click Customize.

5.) Select Your Desired Theme from the List In the: "Icons" Tab.

Thats All!

(!) Remember to select the Theme you want from each of these tabs noted.
(*) An alternate way to get to this dialog is to goto System -> Preferences -> Appearance , Then continue from step 3.. (above)


:::::::::::::::::::::On XFCE Desktops:::::::::::::::::::::


1.) Click On The "XFCE Menu".  (Should be On the far left of either the top or bottom of your desktop.)

2.) Click On The "Settings Menu"  Then --> "XFCE Settings Manager"

3.) Now Click The "Appearance" Category.

4.) Now Select Your Desired theme from the List!, In the "Icons" tab.

5.) Once Done you may click Close ! :)


(!) In case XFCE Settings Manager is not Installed (It really should be, because it's pretty cool), You can also get to the same locations above VIA Clicking:

 "XFCE Menu --> Settings Menu" --> "Appearance"      (then See Step 4)


:::::::::::::::::::::On LXDE Desktops:::::::::::::::::::::


1.) Click On the "Start" Icon (The Circular Icon in the Taskbar/Panel in far left of your screen.)

2.) Select The "Preferences Menu", Then --> "Customize Look and Feel" Menu Item

3.) Now Select Your Desired Icon theme From the List In the: "Icons" Tab And Click Apply.

On OpenBox Desktops

Openbox, out of the box does not have a GUI fronted option to switch your GTK-Theme and Icons.
However most prebuilt openbox desktops Such as CrunchBang(Openbox Edition), ETC will will include the lxappearance utility. If you don't have this utility you should install it via your package manager.

Once it is installed, You can launch it via the command line or run command dialog...

1.) Right click on your Openbox desktop and Find the "lxappearance" Application in your openbox menu. Or Open a terminal or run command prompt and type: lxappearance (and press  enter)

2.) Now Select Your Desired Icon theme From the List In the: "Icons" Tab And Click Apply. 


-------------------------------------------------------------------------------------------------------------------------------------------------------------
Thats All! - Written by Jared Sot. (Please forgive the spelling errors. It's a lot of work to create a theme and complete documentation.)
